from inventory.product import Product
from inventory.inventory import Inventory
from billing.bill import Bill
from billing.sales import SalesTracker


def main():
    inventory = Inventory()
    sales = SalesTracker()

    inventory.add_product(Product(1, "Rice", 60, 50))
    inventory.add_product(Product(2, "Sugar", 45, 40))
    inventory.add_product(Product(3, "Oil", 150, 30))

    while True:
        print("\n1.View Products  2.Create Bill  3.View Sales  4.Exit")
        try:
            choice = int(input("Enter choice: "))

            if choice == 1:
                inventory.display_products()

            elif choice == 2:
                name = input("Customer name: ")
                bill = Bill(name)

                while True:
                    pid = int(input("Product ID (0 to stop): "))
                    if pid == 0:
                        break
                    qty = int(input("Quantity: "))
                    product = inventory.get_product(pid)
                    bill.add_item(product, qty)

                total = bill.print_bill()
                sales.add_sale(total)

            elif choice == 3:
                sales.show_sales()

            elif choice == 4:
                break

            else:
                print("Invalid choice")

        except Exception as e:
            print("Error:", e)


if __name__ == "__main__":
    main()
#to stop code from running automatically when the file is improted

# real example
# you created a calculater app
#you open the app yourself =it should start
# another app uses your calculater code=calculater screen should not open automatically