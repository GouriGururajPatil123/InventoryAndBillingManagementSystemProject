class SalesTracker:
    def __init__(self):
        self.sales = []

    def add_sale(self, amount):
        self.sales.append(amount)

    def show_sales(self):
        print("\n--- Daily Sales ---")
        print("Transactions:", len(self.sales))
        print("Total Sales:", sum(self.sales))