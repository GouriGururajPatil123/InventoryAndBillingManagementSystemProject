from datetime import datetime

class Bill:
    TAX = 0.05
    DISCOUNT = 0.10

    def __init__(self, customer):
        self.customer = customer
        self.items = []

    def add_item(self, product, qty):
        product.update_stock(qty)
        self.items.append((product, qty))

    def calculate_total(self):
        subtotal = sum(p.price * q for p, q in self.items)
        discount = subtotal * self.DISCOUNT if subtotal >= 1000 else 0
        tax = (subtotal - discount) * self.TAX
        return subtotal, discount, tax, subtotal - discount + tax

    def print_bill(self):
        print("\n======= BILL =======")
        print("Customer:", self.customer)
        print("Date:", datetime.now())
        for p, q in self.items:
            print(f"{p.name} x {q} = {p.price * q}")
        subtotal, discount, tax, total = self.calculate_total()
        print("Subtotal:", subtotal)
        print("Discount:", discount)
        print("Tax:", tax)
        print("Total:", total)
        return total
