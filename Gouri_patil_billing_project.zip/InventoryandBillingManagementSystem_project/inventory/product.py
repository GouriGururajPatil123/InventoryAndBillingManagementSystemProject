class Product:
    def __init__(self, pid, name, price, stock):
        self.pid = pid
        self.name = name
        self.price = price
        self.stock = stock

    def update_stock(self, quantity):
        if quantity > self.stock:
            raise ValueError("Insufficient stock")
        self.stock -= quantity

    def __str__(self):
        return f"{self.pid} | {self.name} | Price: {self.price} | Stock: {self.stock}"








