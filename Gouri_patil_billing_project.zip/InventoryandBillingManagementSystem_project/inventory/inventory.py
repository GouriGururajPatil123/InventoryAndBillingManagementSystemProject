from inventory.product import Product

class Inventory:
    def __init__(self):
        self.products = {}

    def add_product(self, product):
        self.products[product.pid] = product

    def display_products(self):
        print("\n  Product List   ")
        for p in self.products.values():
            print(p)

    def get_product(self, pid):
        if pid not in self.products:
            raise KeyError("Product not found")
        return self.products[pid]